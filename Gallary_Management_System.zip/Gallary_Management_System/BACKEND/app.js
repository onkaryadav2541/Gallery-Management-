const adminRoutes = require(routes/adminRoutes);
console.log("Admin routes loaded successfully");
const express = require('express');
const bodyParser = require('body-parser');
const db = require('./config/db'); // Database connection
const userRoutes = require('./routes/userRoutes'); // User routes

const app = express();

// Middleware
app.use(bodyParser.json());

// Routes
app.use('/api/users', userRoutes);

// Test Route
app.get('/', (req, res) => {
    res.send('Welcome to the Art Gallery Management System!');
});

// Sync database and start the server
const PORT = 3000;


db.sync()
    .then(() => {
        app.listen(PORT, () => {
            console.log(`Server running on http://localhost:${PORT}`);
        });
    })
    .catch((err) => {
        console.error('Error syncing database:', err);
    });
